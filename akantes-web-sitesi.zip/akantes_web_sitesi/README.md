# AkanTes web sitesi

Bu klasör, AkanTes için hazırlanmış mobil uyumlu tek sayfalık web sitesidir.

## Dosyalar
- `index.html`: Sayfa içeriği
- `style.css`: Tasarım ve mobil uyumluluk
- `script.js`: Mobil menü ve yıl bilgisi
- `assets/akantes-logo-konsept.png`: Seçilen 3. logo konseptinden geliştirilmiş görsel

## Yayına alma
GitHub Pages ile ücretsiz yayınlamak için:
1. GitHub'da `akantes` adlı bir depo oluşturun.
2. Bu klasördeki dosyaları deponun ana dizinine yükleyin.
3. Repository Settings > Pages bölümünden `Deploy from a branch` ve `main` / `/root` seçin.
4. Yayın adresiniz GitHub tarafından gösterilir.

Telefon ve WhatsApp bağlantıları `0552 173 00 05` numarasına ayarlanmıştır.
Fiyat listesi ve fiziksel adres eklenmemiştir. Temsili görseller gerçek iş fotoğrafı gibi sunulmamıştır.
